public class End extends Element {
  public void Print() {
    System.out.print("End of Sequence");
  }

  @Override
  public boolean equals(Object o) {
    return true;
  }

}