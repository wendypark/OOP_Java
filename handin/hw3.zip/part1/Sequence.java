class Sequence extends Element {

	private Element element;
	private Sequence next;

	public Sequence(){
		element = null;
		next = null; 
	}
     
}
